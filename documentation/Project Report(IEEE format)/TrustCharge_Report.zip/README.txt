TrustCharge — filled List of Figures and List of Tables

Files:
- list_of_figures.tex: automatic LaTeX List of Figures command.
- list_of_tables.tex: automatic LaTeX List of Tables command.
- manual_lists.tex: filled manual list pages using the captions and page numbers
  visible in the TrustCharge_Project_Report PDF found in the available project files.

IMPORTANT:
The manual list page numbers match the report version that has:
  Figures 4.1–4.4 on pages 15–16
  Tables 2.1, 3.1–3.2, and 4.1–4.2 on pages 7–14.
If your current source .tex has different pagination, compile the report and update
the page numbers accordingly. Prefer the automatic commands if all figures/tables
use \caption{} and are compiled at least twice.

How to use:
1. Put the chosen .tex file in the same folder as your main report .tex file.
2. To use automatic lists, replace the blank list pages with:
      \input{list_of_figures}
      \input{list_of_tables}
3. Make sure each figure/table in the report has a proper \caption{...}.
4. Compile twice so LaTeX updates the list files and page numbers.

The original PDF does not contain its editable LaTeX source, so this ZIP provides
the filled list pages and insertion snippets, not a full reconstruction of the
original source project.

UPDATED PACKAGE: Added actual LaTeX figure and table environments and included screenshot image assets. Compile main.tex twice to refresh List of Figures and List of Tables. Please verify that the supplied screenshots correspond to the captions before submission.
